﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PathFinder.Algorithm_Test
{
    public enum TieBreakingStrategy
    {
        NONE, HIGHEST_G_VALUES, SMALLEST_G_VALUES
    }
}
